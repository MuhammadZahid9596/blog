<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class AddRouteCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:add-route-command {username}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $username = $this->argument('username');
        $routeDefinition = "// Automatically generated route for $username\n";
        $routeDefinition .= "Route::prefix('$username')->group(function () {\n";
        $routeDefinition .= "    // Define your routes here\n";
        $routeDefinition .= "    Route::get('example', function () {\n";
        $routeDefinition .= "    });\n";
        // Add more routes as needed
        $routeDefinition .= "});\n\n";

        file_put_contents(base_path('routes/web.php'), $routeDefinition, FILE_APPEND);

        $this->info("Route added successfully: $username");
    }
}
