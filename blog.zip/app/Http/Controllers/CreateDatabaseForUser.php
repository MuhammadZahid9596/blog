<?php
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Http\Request;

class CreateDatabaseForUser extends Migration
{
    public function createDB($request_data)
    {
        dd($request_data);
        $dbName = 'user_database'; // Replace with generated database name
        // Create the database
        DB::statement('CREATE DATABASE ' . $dbName);
        // Configure the connection
        config(['database.connections.user_db' => [
            'driver' => 'mysql',
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '3306'),
            'database' => $dbName,
            'username' => env('DB_USERNAME', 'root'),
            'password' => env('DB_PASSWORD', ''),
            'unix_socket' => env('DB_SOCKET', ''),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'strict' => true,
            'engine' => null,
        ]]);
        // Run migrations for the new connection
        Schema::connection('user_db')->create('example_table', function (Blueprint $table) {
            $table->id();
            // Define your table columns here
            $table->timestamps();
        });
    }
}
?>