<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::view('login','livewire.home');
// Automatically generated route for basit
Route::prefix('basit')->group(function () {
    // Define your routes here
    Route::get('example', function () {
    });
});

// Automatically generated route for zahid
Route::prefix('zahid')->group(function () {
    // Define your routes here
    Route::get('example', function () {
    });
});

